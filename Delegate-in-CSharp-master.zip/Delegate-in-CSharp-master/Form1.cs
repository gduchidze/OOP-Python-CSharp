﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace delegati123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            int[,] arr = new int[,] { { 2, 4, 5 }, { 2, 6, 7 }, { 4, 6, 7 } };
            
            Class1 obj = new Class1();
            Delegatefunc MyDel = obj.metodi1;
            
            MyDel += obj.metodi2;
            MyDel += obj.metodi3;

            MyDel(arr, label1);
            

            MyDel -= obj.metodi1;
            MyDel -= obj.metodi3;
            MyDel += obj.metodi4;

            MyDel(arr, label2);
           


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int[] arr = new int[100000];

            for (int i = 0; i < arr.Length; i++) 
            {
                arr[i] = random.Next();
            }

            var result = from number in arr
                         where number > 12340
                         select number;
            
            foreach (int num in result) label3.Text += num.ToString() + " ";


        }
    }
}
