﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//4 nomeri 


namespace delegati123
{
    
    delegate void Delegatefunc(int[,] arr, Label lab);
    internal class Class1
    {
        public void metodi1(int[,] arr, Label lab)
        {
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    if (arr[i, j] % 2 == 1)
                    {
                        arr[i, j] *= 7;
                    }
                }

            }
            lab.Text = "";

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {

                    {
                        lab.Text += arr[i, j] + " ";
                    }

                }
                lab.Text += "\n";
            }
        }
        public void metodi2(int[,] arr, Label lab)
        {
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    if (arr[i, j] % 2 == 0)
                    {
                        arr[i, j] *= 4;
                    }
                }
            }
            lab.Text = "";

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {

                    {
                        lab.Text += arr[i, j] + " ";
                    }

                }
                lab.Text += "\n";

            }

        }

        public void metodi3(int[,] arr, Label lab)
        {
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    
                    
                    arr[i, j] *= 20;
                   
                }
            }
            lab.Text = " ";

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {

                    {
                        lab.Text += arr[i, j] + " ";
                    }

                }
                lab.Text += "\n";

            }

        }

        public void metodi4(int[,] arr, Label lab)
        {
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    
                    
                        arr[i, j] -= 5;
                   
                }
            }
            lab.Text = "";

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {

                    {
                        lab.Text += arr[i, j] + " ";
                    }

                }
                lab.Text += "\n";

            }

        }
    }
}
